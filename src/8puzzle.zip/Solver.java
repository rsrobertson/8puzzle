import edu.princeton.cs.algs4.Stack;

/**
 * Created by rsraloha on 5/23/17.
 */
public class Solver {

    public Solver(Board initial){

    }
    public boolean isSolvable(){
        return true;
    }
    public int moves(){
        return 0;
    }
    public Iterable<Board> solution(){
        return new Stack<Board>();
    }
    public static void main(String[] args){

    }
}
