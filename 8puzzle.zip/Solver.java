import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by rsraloha on 5/23/17.
 */
public class Solver {
    public Solver(Board initial){

    }
    public boolean isSolvable(){
        throw new NotImplementedException();

    }
    public int moves(){

        throw new NotImplementedException();
    }
    public Iterable<Board> solution(){

        throw new NotImplementedException();
    }
    public static void main(String[] args){

    }
}
